<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

$routes->get('/', 'Home::index');
$routes->get('test', 'Test::index');

/* =========================
   ROUTE CRUD MAHASISWA
   ========================= */

// GET semua mahasiswa
$routes->get('mahasiswa', 'Mahasiswa::index');

// POST tambah mahasiswa
$routes->post('mahasiswa', 'Mahasiswa::create');
