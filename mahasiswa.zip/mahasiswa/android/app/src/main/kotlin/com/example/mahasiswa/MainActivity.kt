package com.example.mahasiswa

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
