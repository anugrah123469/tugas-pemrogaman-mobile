import 'package:flutter/material.dart';
import '../services/api_service.dart';

class MahasiswaForm extends StatelessWidget {
  const MahasiswaForm({super.key});

  @override
  Widget build(BuildContext context) {
    final nimController = TextEditingController();
    final namaController = TextEditingController();
    final jurusanController = TextEditingController();

    return Scaffold(
      appBar: AppBar(title: const Text('Tambah Mahasiswa')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: nimController,
              decoration: const InputDecoration(labelText: 'NIM'),
            ),
            TextField(
              controller: namaController,
              decoration: const InputDecoration(labelText: 'Nama'),
            ),
            TextField(
              controller: jurusanController,
              decoration: const InputDecoration(labelText: 'Jurusan'),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () async {
                await ApiService.addMahasiswa(
                  nimController.text,
                  namaController.text,
                  jurusanController.text,
                );
                Navigator.pop(context);
              },
              child: const Text('Simpan'),
            ),
          ],
        ),
      ),
    );
  }
}
