import 'package:flutter/material.dart';
import '../services/api_service.dart';
import '../models/mahasiswa.dart';
import 'mahasiswa_form.dart';

class MahasiswaList extends StatefulWidget {
  const MahasiswaList({super.key});

  @override
  State<MahasiswaList> createState() => _MahasiswaListState();
}

class _MahasiswaListState extends State<MahasiswaList> {
  late Future<List<Mahasiswa>> futureMahasiswa;

  @override
  void initState() {
    super.initState();
    futureMahasiswa = fetchData();
  }

  Future<List<Mahasiswa>> fetchData() async {
    final data = await ApiService.getMahasiswa();
    return data.map<Mahasiswa>((e) => Mahasiswa.fromJson(e)).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Data Mahasiswa')),
      floatingActionButton: FloatingActionButton(
        child: const Icon(Icons.add),
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const MahasiswaForm()),
          ).then((_) {
            setState(() {
              futureMahasiswa = fetchData();
            });
          });
        },
      ),
      body: FutureBuilder<List<Mahasiswa>>(
        future: futureMahasiswa,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(child: Text('Data kosong'));
          }

          return ListView.builder(
            itemCount: snapshot.data!.length,
            itemBuilder: (context, index) {
              final m = snapshot.data![index];
              return ListTile(
                title: Text(m.nama),
                subtitle: Text('${m.nim} - ${m.jurusan}'),
              );
            },
          );
        },
      ),
    );
  }
}
